var producao_zoom = 10;
var producao_autoplay = true;

setInterval(timer_producao, 3000);
function timer_producao() {
    if(producao_autoplay){
        
        uibuilder.send( { 
                         'topic'             : "producao_autoplay_get",
                         'producao_zoom'     : Number(producao_zoom),
                      } )
    }
    
        uibuilder.send( { 
                         'topic'                     : "producao_chart_bar_get",
                         'producao_chart_bar_data1'  : producao_chart_bar_data1.value,
                         'producao_chart_bar_data2'  : producao_chart_bar_data2.value
                      } )
    
        //ajusta as datas do char bar
        producao_chart_bar_data1_2.textContent = producao_chart_bar_data1.value;
        producao_chart_bar_data2_2.textContent = producao_chart_bar_data2.value;
}

function producao_playpause(){
        uibuilder.send( { 
                         'topic'             : "producao_playpause_get",
                         'producao_zoom'     : Number(producao_zoom),
                         'producao_data'     : producao_data.value,
                         'producao_hora'     : producao_hora.value
                      } )
}

//função obter h:m:s de segundo
function secondsToTime(e){

    var h = Math.floor(e / 3600).toString().padStart(2,'0'),
        m = Math.floor(e % 3600 / 60).toString().padStart(2,'0'),
        s = Math.floor(e % 60).toString().padStart(2,'0');
    
    if(e > 0){return h + ':' + m + ':' + s;}
    if(e <= 0){return 'Concluido!'}
    
}

// run this function when the document is loaded
    window.onload = function() {
        // Start up uibuilder - see the docs for the optional parameters
        uibuilder.start();
    
        // Listen for incoming messages from Node-RED
        uibuilder.onChange('msg', function(msg){
            uibuilder.send( { 'msg': msg } );
            
            if(msg.producao.length == 0){
                alert("Dados não encontrados...");
            }
            
            if(msg.producao !== undefined){

                //atualizar data e hora
                var producao_data = document.querySelector('#producao_data');
                producao_data.value = msg.producao[0].data;
                var producao_hora = document.querySelector('#producao_hora');
                producao_hora.value = msg.producao[0].hora;
                
                //atualizar Linha01  
                document.querySelector('#Linha01_produto_nome').textContent                = msg.producao[0].Linha01_produto_nome;
                var Linha01_quantidade_atual                                               = msg.producao[0].Linha01_quantidade_atual;
                var Linha01_quantidade_final                                               = msg.producao[0].Linha01_quantidade_final;
                var Linha01_porcentagem                                                    = String((Linha01_quantidade_atual * 100)/Linha01_quantidade_final) + "%";    
                var Linha01_progressbar                                                    = "width: " + Linha01_porcentagem; 
                var Linha01_velocidade                                                     = String(msg.producao[0].Linha01_velocidade) + " Uni/min";
                var Linha01_producao_t_estimado                                            = secondsToTime(((Linha01_quantidade_final-Linha01_quantidade_atual)*60)/msg.producao[0].Linha01_velocidade);
 
                document.querySelector('#Linha01_velocidade').textContent                  = Linha01_velocidade;
                document.querySelector('#Linha01_quantidade_atual').textContent            = Linha01_quantidade_atual;
                document.querySelector('#Linha01_quantidade_final').textContent            = Linha01_quantidade_final;
                document.querySelector('#Linha01_porcentagem').textContent                 = Linha01_porcentagem;
                document.querySelector('#Linha01_progressbar').style                       = Linha01_progressbar;
                document.querySelector('#Linha01_producao_t_estimado').textContent         = Linha01_producao_t_estimado;
                document.querySelector('#Linha01_temperatura').textContent                 = msg.producao[0].Linha01_temperatura;
                document.querySelector('#Linha01_pressao').textContent                     = msg.producao[0].Linha01_pressao;
                document.querySelector('#Linha01_umidade').textContent                     = msg.producao[0].Linha01_umidade;
                
                //atualizar grafico line
                var x      = msg.producao.map( x => x.hora);
                var y1     = msg.producao.map( x => x.Linha01_velocidade);
                var y2     = msg.producao.map( x => x.Linha02_velocidade);
                var y3     = msg.producao.map( x => x.Linha03_velocidade);
                
                producao_chart_line.data.datasets[0].data = [];
                producao_chart_line.data.datasets[1].data = [];
                producao_chart_line.data.datasets[2].data = [];
                producao_chart_line.update();
                
                producao_chart_line.data.labels = x.reverse();
                producao_chart_line.data.datasets[0].data = y1.reverse();
                producao_chart_line.data.datasets[1].data = y2.reverse();
                producao_chart_line.data.datasets[2].data = y3.reverse();
                producao_chart_line.update();
            }
            
           if(msg.producao_chart_bar !== undefined){

                //atualizar grafico bar
                var bar_x                                = msg.producao_chart_bar.map( x => x.produto);
                var bar_y                                = msg.producao_chart_bar.map( x => x.total);
                var bar_z                                = msg.producao_chart_bar.map( x => x.total2);
                var bar_w                                = msg.producao_chart_bar.map( x => x.total3);

                producao_chart_bar.data.labels           = bar_x.reverse();
                producao_chart_bar.data.datasets[0].data = bar_y .reverse();
                producao_chart_bar.data.datasets[1].data = bar_z .reverse();
                producao_chart_bar.data.datasets[2].data = bar_w .reverse();

                producao_chart_bar.update(); 
            }
        })
    }
    
    //producao_data
    const producao_data = document.querySelector('#producao_data');
    producao_data.onclick = function() {
        producao_autoplay = false;
        icon_playpause.classList.replace('fa-pause', 'fa-play');
    }
    
    //producao_hora
    const producao_hora = document.querySelector('#producao_hora');
    producao_hora.onclick = function() {
        producao_autoplay = false;
        icon_playpause.classList.replace('fa-pause', 'fa-play');
    }
    
    //producao_data_hora_play
    const producao_data_hora_play = document.querySelector('#producao_data_hora_play');
    producao_data_hora_play.onclick = function() {
        
        producao_autoplay = false;
        icon_playpause.classList.replace('fa-pause', 'fa-play');

        if((producao_data.value != "")&&(producao_hora.value != "")){
            producao_playpause();
        }
    }
    
    //icon_playpause
    const icon_playpause = document.querySelector('#icon_playpause');
    
    //producao_data_hora_refresh
    const producao_data_hora_refresh = document.querySelector('#producao_data_hora_refresh');
    producao_data_hora_refresh.onclick = function() {
        producao_autoplay = true;
        console.log("producao_autoplay = true");
        icon_playpause.classList.replace('fa-play', 'fa-pause');
        timer_producao();
    }
    
    //producao_chart_zoom
    const producao_chart_zoom = document.querySelector('#producao_chart_zoom');
    producao_chart_zoom.onclick = function() {
        
        var producao_chart_zoom      = document.querySelector("#producao_chart_zoom");
        var zoom                     = producao_chart_zoom.value;
        console.log(Number(zoom));
        producao_zoom = zoom * 10;
        
        if(producao_autoplay == true){
            timer_producao();
        }else{
            if((producao_data.value != "")&&(producao_hora.value != "")){
                producao_playpause();
            }
        }
    }
    
    //obtend data
    var data = new Date();
    var dia = String(data.getDate()).padStart(2, '0');
    var mes = String(data.getMonth() + 1).padStart(2, '0'); 
    var ano = data.getFullYear();
    
    //producao_chart_bar_data1_2
    const producao_chart_bar_data1_2 = document.querySelector('#producao_chart_bar_data1_2');
    //producao_chart_bar_data1
    const producao_chart_bar_data1 = document.querySelector('#producao_chart_bar_data1');
    producao_chart_bar_data1.value = ano + '-' + mes + '-' + '01';
    
    //producao_chart_bar_data2_2
    const producao_chart_bar_data2_2 = document.querySelector('#producao_chart_bar_data2_2');
    //producao_chart_bar_data2
    const producao_chart_bar_data2 = document.querySelector('#producao_chart_bar_data2');
    producao_chart_bar_data2.value = ano + '-' + mes + '-' + dia;
    
    