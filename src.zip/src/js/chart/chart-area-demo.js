var ctx = document.getElementById("producao_chart_line");
var producao_chart_line = new Chart(ctx, {
    type: 'line',
    data: {
            labels: [],
            datasets: [{
                        label: 'Linha01',
                        data: [],
                        fill: false,
                        borderColor: "#1cc88a",
                        tension: 0.3
                      },{
                        label: 'Linha02',
                        data: [],
                        fill: false,
                        borderColor: "#e74a3b",
                        tension: 0.3
                      },{
                        label: 'Linha03',
                        data: [],
                        fill: false,
                        borderColor: "#36b9cc",
                        tension: 0.3
                      }],
            options: { 
                      legend: {labels:{boxWidth:10,usePointStyle: true,}},
              title: {
                display: false,
              },
              scales: {y:{Min: 0}} 
            }
                  }
});
