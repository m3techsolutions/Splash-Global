var ctx = document.getElementById("producao_chart_bar");
var producao_chart_bar = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: [],
      datasets: [
        { 
          label: ["Empacotados"],
          backgroundColor: ["#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df","#4e73df"],
          data: []
        },
        { 
          label: ["Vendido"],
          backgroundColor: ["#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700","#FFD700"],
          data: []
        },
        { 
          label: ["Estoque"],
          backgroundColor: ["#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32","#32CD32"],
          data: []
        }
      ]
    },
    options: { 
              legend: {labels:{boxWidth:10,usePointStyle: true,}},
      title: {
        display: false,
      },
      scales: {y:{Min: 0}} 
    }
});

